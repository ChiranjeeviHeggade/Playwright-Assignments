import { test, expect } from "@playwright/test";
import exp from "constants";

test.only("Create Salesforce Lead", async ({ page }) => {

  // STEP 1: OPEN THE SALESFORCE URL
  await page.goto("https://login.salesforce.com/");

  // STEP 2: VALIDATE THE SALESFORCE IMAGE IS VISIBLE ON THE LOGIN SCREEN
  await expect(page.getByAltText("Salesforce")).toBeVisible();

  // STEP 3: ENTER THE CREDENTIALS
  await page.locator("#username").fill("chiranjeevi.heggade@gmail.com");
  await page.locator("#password").fill("Test@2024");
  await page.locator("#Login").click();

  await page.waitForLoadState('domcontentloaded')

  // STEP 4: WAIT FOR APP LAUNCHER ICON TO DISPLAY AND CLICK

  await page.waitForSelector(".slds-icon-waffle");
  await expect(page.locator(".slds-icon-waffle")).toBeVisible();
  await page.locator(".slds-icon-waffle").click();
  
  // STEP 5: WAIT FOR THE 'View All' LINK TO BE VISIBLE AND CLICK
  await expect(
    page.locator("button[aria-label='View All Applications']")
  ).toBeVisible();
  await page.locator("button[aria-label='View All Applications']").click();

  // STEP 6: WAIT FOR THE SEARCH INPUT BOX TO BE EDITABLE AND ENTER THE APP NAME
  await expect(page.getByPlaceholder("Search apps or items...")).toBeEditable();
  await page.getByPlaceholder("Search apps or items...").fill("Sales");

  // STEP 7: CLICK ON THE 'SALES' APP
  await page
    .locator("//p[contains(text(),'Manage your sales')]/preceding-sibling::a")
    .click();

  // STEP 8: WAIT FOR THE 'LEADS' TAB TO BE VISIBLE AND CLICK
  await expect(page.locator("a[href*='/Lead/home']")).toBeVisible();
  await page.locator("a[href*='/Lead/home']").click();

  // STEP 9: WAIT FOR THE 'NEW' BUTTON TO BE VISIBLE AND CLICK
  await expect(
    page.locator("button[class*='slds-button_neutral middleButton']")
  ).toBeVisible();
  await page
    .locator("button[class*='slds-button_neutral middleButton']")
    .click();

  // STEP 10: SELECT THE SALUTATION FROM THE DROPDOWN LIST
  await expect(
    page.locator("button[aria-label*='Salutation'][data-value='--None--']")
  ).toBeAttached();
  await page
    .locator("button[aria-label*='Salutation'][data-value='--None--']")
    .click();

  await expect(
    page.locator("lightning-base-combobox-item[data-value='Mr.']")
  ).toBeAttached();
  await page.locator("lightning-base-combobox-item[data-value='Mr.']").click();
});
