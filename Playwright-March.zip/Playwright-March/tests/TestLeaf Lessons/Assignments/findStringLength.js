var sentenceOne = 'Hello World'
var splitWordsOne = sentenceOne.split(" ")
console.log('Example 1: The Length of the Last Word:', splitWordsOne[1].length);

var sentenceTwo = ' fly me to the moon '
var trimSentence = sentenceTwo.trim(" ")
var splitWordsTwo = trimSentence.split(" ")
console.log('Example 2: The Length of the Last Word:', splitWordsTwo[4].length);
