function printOddNumbers() {
    for (let index = 1; index <= 25; index++) {

        if (index % 2 != 0) {
            console.log(index);
        }

    }
}
printOddNumbers()