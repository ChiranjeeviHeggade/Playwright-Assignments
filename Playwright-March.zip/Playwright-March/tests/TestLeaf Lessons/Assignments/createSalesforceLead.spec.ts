import { test, expect } from "@playwright/test";
import exp from "constants";

test("Create Salesforce Lead", async ({ page }) => {
  await page.goto("https://login.salesforce.com/");
  /*
    await expect( async () => {
      await expect(page.getByAltText("Salesforce")).toBeVisible()
    }).toPass()
   */
  await expect(page.getByAltText("Salesforce")).toBeVisible();

  await page.locator("#username").fill("chiranjeevi.heggade@gmail.com");
  await page.locator("#password").fill("Test@2024");
  await page.locator("#Login").click();

  await expect(async () => {
    await expect(page.locator(".slds-icon-waffle")).toBeVisible();
  }).toPass();

  await page.locator(".slds-icon-waffle").click();

  await expect(async () => {
    await expect(
      page.locator("button[aria-label='View All Applications']")
    ).toBeVisible();
    await page.locator("button[aria-label='View All Applications']").click();
  }).toPass();

  await page.locator("input[part='input']").fill("Sales");

  // Click on 'Sales' app
  await expect(async () => {
    await page
      .locator("//p[contains(text(),'Manage your sales')]/preceding-sibling::a")
      .click();
  }).toPass();

  // Click on 'Leads' Tab
  await expect(async () => {
    await page.locator("a[href*='/Lead/home']").click();
  }).toPass();

  // Click on 'New' button
  await page
    .locator("button[class*='slds-button_neutral middleButton']")
    .click();

  // Select the Salutation

  await expect(async () => {
    await expect(
      page.locator("button[aria-label*='Salutation'][data-value='--None--']")
    ).toBeAttached();
    await page
      .locator("button[aria-label*='Salutation'][data-value='--None--']")
      .click();
  }).toPass();

  await expect(
    page.locator("lightning-base-combobox-item[data-value='Mr.']")
  ).toBeAttached();
  await page.locator("lightning-base-combobox-item[data-value='Mr.']").click();
});
