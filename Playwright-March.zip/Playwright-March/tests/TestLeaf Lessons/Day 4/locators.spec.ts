import { chromium, test } from "@playwright/test";

test("Launch Browser", async () => {
  // To Launch the 'chrome' Browser in 'headless' mode 
  const browser = await chromium.launch();

  // To Create the Browser Context
  const context = await browser.newContext();

  // To Create a New Page
  const page = await context.newPage();

  // Open the URL
  await page.goto('https://login.salesforce.com');
  //await page.goto('https://www.leafground.com/dashboard.xhtml');
  
  await page.waitForTimeout(5000);

  
});
