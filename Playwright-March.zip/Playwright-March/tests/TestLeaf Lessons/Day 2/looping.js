/* for loop */

for (let index = 1; index <= 5; index++) {
    console.log(index);
}

console.log("****************")

/* while loop */

let val = 5
while (val >= 1) {
    console.log(val);
    val--
}

console.log("****************")

/* do-while loop */
let value = 1
do {
    console.log(value);
    value++
} while (value <= 5);