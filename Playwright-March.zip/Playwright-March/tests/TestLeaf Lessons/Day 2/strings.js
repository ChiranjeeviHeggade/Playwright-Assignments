/**
 *  There are 2 types - Primitive and String Literals
 * 
 *  */

const browserName = 'chrome' //String Literal

let browserNewName = new String('chrome') //String Object

// Using backticks ` ` -- ${} --> template literal
let testCaseCount = 100
console.log(`Total Test Count: ${testCaseCount}`);

console.log('The Length of the String: ', browserName.length);
console.log('The Index of the Specific Character: ', browserName.indexOf('e'));
console.log('The Character at the Specific Index: ', browserName.charAt(0));
console.log('Includes the Search String: ', browserName.includes('rome'));
console.log('To Uppercase: ', browserName.toUpperCase());

let sentence = 'The Price of the Bag is 272 USD'

console.log('The Exact Price of the Bag:', sentence.slice(23, 27));
console.log('The Exact Price of the Bag with Currency:', sentence.split('is ')[1]);

console.log('****** REVERSE STRING ********');
function doReverse(courseName) {
    let characters = courseName.split('')
    let reversedString = ""
    for (let index = characters.length - 1; index >= 0; index--) {
        reversedString = reversedString + characters[index]
    }
    return reversedString
}
console.log('The Reverse String: ', doReverse('Playwright'));